import { Link, useLocation } from "wouter";
import { useCart } from "@/lib/cart";
import { useRestaurant } from "@/lib/restaurant-context";
import { useRestaurantPath } from "@/lib/use-slug";
import { ShoppingBag, Menu as MenuIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Layout({ children }: { children: React.ReactNode }) {
  const { itemCount } = useCart();
  const [location] = useLocation();
  const { restaurant } = useRestaurant();
  const rpath = useRestaurantPath();

  const name = restaurant?.name ?? "Terra";

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href={rpath("")} className="flex items-center gap-2">
              <span className="font-serif text-2xl font-bold text-primary">{name}</span>
            </Link>
            <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
              <Link href={rpath("/menu")} className={`transition-colors hover:text-primary ${location.includes('/menu') ? 'text-primary' : 'text-foreground/60'}`}>
                Our Menu
              </Link>
              <Link href={rpath("/my-orders")} className={`transition-colors hover:text-primary ${location.includes('/my-orders') ? 'text-primary' : 'text-foreground/60'}`}>
                My Orders
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <Link href={rpath("/checkout")}>
              <Button variant="outline" size="sm" className="relative">
                <ShoppingBag className="h-4 w-4 mr-2" />
                Cart
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Button>
            </Link>
            <Button variant="ghost" size="icon" className="md:hidden">
              <MenuIcon className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t bg-card mt-12 py-12">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-serif text-xl font-bold text-primary">{name}</span>
            <span className="text-sm text-muted-foreground ml-2">© {new Date().getFullYear()} {name}. All rights reserved.</span>
          </div>
          {restaurant?.phone && (
            <span className="text-sm text-muted-foreground">{restaurant.phone}</span>
          )}
        </div>
      </footer>
    </div>
  );
}
