import { Link, useLocation, useParams } from "wouter";
import {
  LayoutDashboard, UtensilsCrossed, Tags, ShoppingCart,
  ArrowLeft, LogOut, Bell, Palette, Menu as MenuIcon, X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAdminAuth } from "@/lib/admin-auth";
import { useListOrders, getListOrdersQueryKey } from "@workspace/api-client-react";
import { useEffect, useRef, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { useRestaurant } from "@/lib/restaurant-context";

function buildNav(slug: string) {
  return [
    { href: `/r/${slug}/admin`, label: "Dashboard", icon: LayoutDashboard },
    { href: `/r/${slug}/admin/orders`, label: "Orders", icon: ShoppingCart },
    { href: `/r/${slug}/admin/menu`, label: "Menu Items", icon: UtensilsCrossed },
    { href: `/r/${slug}/admin/categories`, label: "Categories", icon: Tags },
    { href: `/r/${slug}/admin/appearance`, label: "Appearance", icon: Palette },
  ];
}

function NewOrderWatcher() {
  const { data: orders } = useListOrders(
    { status: "pending" },
    { query: { queryKey: getListOrdersQueryKey({ status: "pending" }), refetchInterval: 10000 } }
  );
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const prevIdsRef = useRef<Set<number>>(new Set());
  const initialized = useRef(false);
  const [newCount, setNewCount] = useState(0);

  useEffect(() => {
    if (!orders) return;
    const currentIds = new Set(orders.map((o) => o.id));

    if (!initialized.current) {
      initialized.current = true;
      prevIdsRef.current = currentIds;
      return;
    }

    const incoming = orders.filter((o) => !prevIdsRef.current.has(o.id));
    if (incoming.length > 0) {
      setNewCount((n) => n + incoming.length);
      incoming.forEach((order) => {
        toast({
          title: `🔔 New Order #${order.id}`,
          description: `${order.customerName} — ${order.items.length} item${order.items.length !== 1 ? "s" : ""} — Rs ${Number(order.total).toFixed(0)}`,
          duration: 8000,
        });
      });
      queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
    }
    prevIdsRef.current = currentIds;
  }, [orders, toast, queryClient]);

  return newCount > 0 ? (
    <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center">
      {newCount > 9 ? "9+" : newCount}
    </span>
  ) : null;
}

function Sidebar({
  slug,
  location,
  session,
  onClose,
}: {
  slug: string;
  location: string;
  session: any;
  onClose?: () => void;
}) {
  const navItems = buildNav(slug);
  const { logout } = useAdminAuth();
  const [, setLocation] = useLocation();
  const { restaurant } = useRestaurant();

  const handleLogout = () => {
    logout();
    setLocation(`/r/${slug}/admin/login`);
    onClose?.();
  };

  const displayName = restaurant?.name ?? session?.name ?? "Terra";

  return (
    <div className="w-full h-full flex flex-col bg-card">
      <div className="h-16 flex items-center justify-between px-6 border-b shrink-0">
        <div className="min-w-0">
          <span className="font-serif text-lg font-bold text-primary truncate block">{displayName} Admin</span>
        </div>
        {onClose && (
          <button onClick={onClose} className="ml-2 text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href || (item.href !== `/r/${slug}/admin` && location.startsWith(item.href));
          const isOrders = item.href.endsWith("/orders");
          return (
            <Link key={item.href} href={item.href} onClick={onClose}>
              <span className={cn(
                "relative flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors cursor-pointer",
                isActive ? "bg-primary text-primary-foreground" : "hover:bg-muted text-muted-foreground hover:text-foreground"
              )}>
                <span className="relative shrink-0">
                  <Icon className="h-4 w-4" />
                  {isOrders && <NewOrderWatcher />}
                </span>
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t space-y-1 shrink-0">
        <Link href={`/r/${slug}`} onClick={onClose}>
          <span className="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer">
            <ArrowLeft className="h-4 w-4" />
            Back to Site
          </span>
        </Link>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors cursor-pointer"
        >
          <LogOut className="h-4 w-4" />
          Logout
        </button>
      </div>
    </div>
  );
}

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { session } = useAdminAuth();
  const params = useParams<{ slug: string }>();
  const slug = params.slug ?? session?.slug ?? "terra";
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-[100dvh] flex bg-muted/40">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex w-64 border-r flex-col shrink-0">
        <Sidebar slug={slug} location={location} session={session} />
      </aside>

      {/* Mobile sidebar overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <div className="relative w-72 max-w-[85vw] shadow-xl">
            <Sidebar slug={slug} location={location} session={session} onClose={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      <main className="flex-1 flex flex-col min-h-[100dvh] overflow-y-auto">
        {/* Mobile top bar */}
        <div className="md:hidden flex items-center gap-3 px-4 h-14 border-b bg-card sticky top-0 z-40">
          <button onClick={() => setMobileOpen(true)} className="text-muted-foreground hover:text-foreground">
            <MenuIcon className="h-5 w-5" />
          </button>
          <span className="font-serif font-bold text-primary">Admin Panel</span>
        </div>

        {children}
      </main>
    </div>
  );
}
