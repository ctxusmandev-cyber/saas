import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useRestaurant } from "@/lib/restaurant-context";
import { useParams } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Palette, ImageIcon, Type, Save, Eye } from "lucide-react";

const PRESET_COLORS = [
  { label: "Terra Orange", value: "#e35a2a" },
  { label: "Forest Green", value: "#2d6a4f" },
  { label: "Royal Blue", value: "#1d4ed8" },
  { label: "Deep Purple", value: "#7c3aed" },
  { label: "Ruby Red", value: "#dc2626" },
  { label: "Gold", value: "#d97706" },
  { label: "Ocean Teal", value: "#0d9488" },
  { label: "Rose Pink", value: "#db2777" },
];

export default function AdminAppearance() {
  const { restaurant } = useRestaurant();
  const params = useParams<{ slug: string }>();
  const slug = params.slug ?? restaurant?.slug ?? "terra";
  const { toast } = useToast();

  const [themeColor, setThemeColor] = useState(restaurant?.themeColor ?? "#e35a2a");
  const [heroTitle, setHeroTitle] = useState(restaurant?.heroTitle ?? "");
  const [heroSubtitle, setHeroSubtitle] = useState(restaurant?.heroSubtitle ?? "");
  const [heroImageUrl, setHeroImageUrl] = useState(restaurant?.heroImageUrl ?? "");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (restaurant) {
      setThemeColor(restaurant.themeColor ?? "#e35a2a");
      setHeroTitle(restaurant.heroTitle ?? "");
      setHeroSubtitle(restaurant.heroSubtitle ?? "");
      setHeroImageUrl(restaurant.heroImageUrl ?? "");
    }
  }, [restaurant]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch(`/api/restaurants/${slug}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ themeColor, heroTitle, heroSubtitle, heroImageUrl }),
      });
      if (!res.ok) throw new Error("Failed to save");
      toast({ title: "Appearance saved!", description: "Changes will appear on the customer site immediately." });
    } catch {
      toast({ title: "Error saving", description: "Please try again.", variant: "destructive" });
    }
    setSaving(false);
  };

  return (
    <AdminLayout>
      <div className="p-4 md:p-8 max-w-4xl">
        <div className="mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-serif font-bold">Appearance</h1>
          <p className="text-sm text-muted-foreground mt-1">Customize your restaurant's customer-facing website</p>
        </div>

        <div className="space-y-6">
          {/* Theme Color */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <Palette className="h-5 w-5 text-primary" />
                Brand Color
              </CardTitle>
              <CardDescription>Choose the primary color used throughout your site</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {PRESET_COLORS.map((c) => (
                  <button
                    key={c.value}
                    title={c.label}
                    onClick={() => setThemeColor(c.value)}
                    className="w-9 h-9 rounded-full border-2 transition-all hover:scale-110"
                    style={{
                      backgroundColor: c.value,
                      borderColor: themeColor === c.value ? "#000" : "transparent",
                      boxShadow: themeColor === c.value ? "0 0 0 2px white, 0 0 0 4px " + c.value : "none",
                    }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <input
                    type="color"
                    value={themeColor}
                    onChange={(e) => setThemeColor(e.target.value)}
                    className="w-12 h-10 rounded cursor-pointer border border-input p-0.5"
                  />
                </div>
                <Input
                  value={themeColor}
                  onChange={(e) => setThemeColor(e.target.value)}
                  placeholder="#e35a2a"
                  className="w-36 font-mono text-sm"
                  maxLength={7}
                />
                <div
                  className="flex-1 h-10 rounded-md border"
                  style={{ backgroundColor: themeColor }}
                />
              </div>
            </CardContent>
          </Card>

          {/* Hero Section */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <Type className="h-5 w-5 text-primary" />
                Hero Section Text
              </CardTitle>
              <CardDescription>The big headline section visitors see first on your homepage</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label>Headline</Label>
                <Input
                  value={heroTitle}
                  onChange={(e) => setHeroTitle(e.target.value)}
                  placeholder="Nourish Your Body. Delight Your Soul."
                />
              </div>
              <div className="space-y-1.5">
                <Label>Subtext</Label>
                <Textarea
                  value={heroSubtitle}
                  onChange={(e) => setHeroSubtitle(e.target.value)}
                  placeholder="A short description of your restaurant shown below the headline..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Hero Image */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <ImageIcon className="h-5 w-5 text-primary" />
                Hero Background Image
              </CardTitle>
              <CardDescription>Image URL for the homepage hero background. Use a high-quality landscape photo.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label>Image URL</Label>
                <Input
                  value={heroImageUrl}
                  onChange={(e) => setHeroImageUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                />
              </div>
              {heroImageUrl && (
                <div className="rounded-lg overflow-hidden border aspect-[16/5] bg-muted">
                  <img
                    src={heroImageUrl}
                    alt="Hero preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Preview box */}
          <Card className="overflow-hidden">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <Eye className="h-5 w-5 text-primary" />
                Live Preview
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div
                className="relative w-full aspect-[16/6] flex items-center justify-center overflow-hidden"
                style={{
                  backgroundImage: heroImageUrl ? `url(${heroImageUrl})` : undefined,
                  backgroundColor: themeColor,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              >
                <div className="absolute inset-0 bg-black/40" />
                <div className="relative z-10 text-center text-white px-6">
                  <h2 className="text-xl md:text-3xl font-bold font-serif leading-tight">
                    {heroTitle || "Nourish Your Body. Delight Your Soul."}
                  </h2>
                  {heroSubtitle && (
                    <p className="mt-2 text-sm text-white/80 max-w-md mx-auto line-clamp-2">{heroSubtitle}</p>
                  )}
                  <div
                    className="mt-4 inline-flex items-center gap-2 px-6 py-2 rounded-full text-sm font-semibold text-white"
                    style={{ backgroundColor: themeColor }}
                  >
                    Order Now →
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end pb-4">
            <Button onClick={handleSave} disabled={saving} className="gap-2 px-8">
              <Save className="h-4 w-4" />
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
