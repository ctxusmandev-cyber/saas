import { Layout } from "@/components/layout";
import { useCart } from "@/lib/cart";
import { formatCurrency } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useCreateOrder, getGetOrderQueryKey } from "@workspace/api-client-react";
import { saveOrderId } from "@/lib/order-history";
import { useLocation } from "wouter";
import { useRestaurantPath } from "@/lib/use-slug";
import { Trash2, Banknote, Smartphone } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

const PAYMENT_METHODS = [
  {
    value: "cash_on_delivery",
    label: "Cash on Delivery",
    description: "Pay when your order arrives",
    icon: Banknote,
    color: "text-green-600",
    bg: "bg-green-50 border-green-200",
    activeBg: "bg-green-100 border-green-500",
  },
  {
    value: "jazz_cash",
    label: "JazzCash",
    description: "Pay via JazzCash mobile wallet",
    icon: Smartphone,
    color: "text-red-600",
    bg: "bg-red-50 border-red-200",
    activeBg: "bg-red-100 border-red-500",
  },
  {
    value: "easy_paisa",
    label: "EasyPaisa",
    description: "Pay via EasyPaisa mobile wallet",
    icon: Smartphone,
    color: "text-emerald-600",
    bg: "bg-emerald-50 border-emerald-200",
    activeBg: "bg-emerald-100 border-emerald-500",
  },
] as const;

type PaymentMethodValue = "cash_on_delivery" | "jazz_cash" | "easy_paisa";

const checkoutSchema = z.object({
  customerName: z.string().min(2, "Name is required"),
  customerPhone: z.string().min(10, "Valid phone number is required"),
  customerAddress: z.string().optional(),
  notes: z.string().optional(),
  paymentMethod: z.enum(["cash_on_delivery", "jazz_cash", "easy_paisa"]),
});

type CheckoutFormValues = z.infer<typeof checkoutSchema>;

export default function Checkout() {
  const { items, total, removeFromCart, updateQuantity, clearCart } = useCart();
  const [, setLocation] = useLocation();
  const rpath = useRestaurantPath();
  const createOrder = useCreateOrder();
  const queryClient = useQueryClient();

  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      customerName: "",
      customerPhone: "",
      customerAddress: "",
      notes: "",
      paymentMethod: "cash_on_delivery",
    },
  });

  const selectedPayment = form.watch("paymentMethod");

  const onSubmit = (data: CheckoutFormValues) => {
    if (items.length === 0) return;

    createOrder.mutate(
      {
        data: {
          ...data,
          items: items.map((item) => ({
            menuItemId: item.menuItemId,
            quantity: item.quantity,
          })),
        },
      },
      {
        onSuccess: (order) => {
          clearCart();
          saveOrderId(order.id);
          queryClient.invalidateQueries({ queryKey: getGetOrderQueryKey(order.id) });
          setLocation(rpath(`/order/${order.id}`));
        },
      }
    );
  };

  if (items.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-4xl font-serif font-bold mb-4">Your Cart is Empty</h1>
          <p className="text-muted-foreground mb-8">Looks like you haven't added anything to your order yet.</p>
          <Button onClick={() => setLocation(rpath("/menu"))}>Browse Menu</Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-serif font-bold mb-8">Checkout</h1>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-7">
            <div className="bg-card border rounded-xl p-6 mb-6">
              <h2 className="text-2xl font-serif font-bold mb-6">Customer Information</h2>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="customerName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Ahmed Ali" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="customerPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="03XX-XXXXXXX" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="customerAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Delivery Address (Optional)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Leave blank for pickup"
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Order Notes</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Any allergies or special instructions?"
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="paymentMethod"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-semibold">Payment Method</FormLabel>
                        <div className="grid grid-cols-1 gap-3 mt-2">
                          {PAYMENT_METHODS.map((method) => {
                            const Icon = method.icon;
                            const isSelected = field.value === method.value;
                            return (
                              <button
                                key={method.value}
                                type="button"
                                onClick={() => field.onChange(method.value)}
                                className={cn(
                                  "flex items-center gap-4 p-4 rounded-xl border-2 text-left transition-all",
                                  isSelected ? method.activeBg : method.bg + " hover:opacity-80"
                                )}
                              >
                                <div className={cn("p-2 rounded-lg bg-white/60", method.color)}>
                                  <Icon className="w-5 h-5" />
                                </div>
                                <div className="flex-1">
                                  <p className="font-semibold">{method.label}</p>
                                  <p className="text-xs text-muted-foreground">{method.description}</p>
                                </div>
                                <div className={cn(
                                  "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                                  isSelected ? "border-current bg-current" : "border-muted-foreground"
                                )}>
                                  {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full text-lg h-14"
                    disabled={createOrder.isPending}
                  >
                    {createOrder.isPending ? "Placing Order..." : `Place Order - ${formatCurrency(total)}`}
                  </Button>
                </form>
              </Form>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="bg-muted/30 rounded-xl p-6 sticky top-24">
              <h2 className="text-2xl font-serif font-bold mb-6">Order Summary</h2>

              <div className="space-y-4 mb-6 max-h-[400px] overflow-y-auto pr-2">
                {items.map((item) => (
                  <div key={item.menuItemId} className="flex gap-4 items-center bg-card p-3 rounded-lg border">
                    {item.imageUrl ? (
                      <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-md" />
                    ) : (
                      <div className="w-16 h-16 bg-muted rounded-md" />
                    )}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold font-serif truncate">{item.name}</h4>
                      <div className="text-primary font-medium">{formatCurrency(item.price)}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.menuItemId, item.quantity - 1)}
                      >
                        -
                      </Button>
                      <span className="w-4 text-center text-sm font-bold">{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.menuItemId, item.quantity + 1)}
                      >
                        +
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => removeFromCart(item.menuItemId)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>{formatCurrency(total)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Tax (Estimated)</span>
                  <span>{formatCurrency(total * 0.08)}</span>
                </div>
                <div className="flex justify-between font-bold text-xl mt-4 pt-4 border-t">
                  <span>Total</span>
                  <span className="text-primary">{formatCurrency(total * 1.08)}</span>
                </div>

                {selectedPayment && (
                  <div className="mt-3 pt-3 border-t flex items-center gap-2 text-sm text-muted-foreground">
                    <span>Payment:</span>
                    <span className="font-medium text-foreground capitalize">
                      {PAYMENT_METHODS.find(m => m.value === selectedPayment)?.label}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
