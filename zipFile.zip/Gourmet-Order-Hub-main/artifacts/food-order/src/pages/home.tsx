import { Layout } from "@/components/layout";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useListCategories, useListItems } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { formatCurrency } from "@/lib/format";
import { ArrowRight, Utensils } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useRestaurantPath } from "@/lib/use-slug";
import { useRestaurant } from "@/lib/restaurant-context";

export default function Home() {
  const { data: categories, isLoading: isLoadingCategories } = useListCategories();
  const { data: featuredItems, isLoading: isLoadingItems } = useListItems({ featured: true });
  const rpath = useRestaurantPath();
  const { restaurant } = useRestaurant();

  const name = restaurant?.name ?? "Terra";
  const heroTitle = restaurant?.heroTitle || "Nourish Your Body.\nDelight Your Soul.";
  const heroSubtitle = restaurant?.heroSubtitle || restaurant?.description || "Experience the rich, warm flavors of our kitchen. We source local, sustainable ingredients to craft meals that you'll remember long after the last bite.";
  const heroImageUrl = restaurant?.heroImageUrl;

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative w-full h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/40 z-10" />
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-500"
          style={{
            backgroundImage: heroImageUrl ? `url(${heroImageUrl})` : undefined,
            backgroundColor: "hsl(var(--primary))",
          }}
        />
        <div className="relative z-20 text-center text-white px-4 max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold font-serif leading-tight whitespace-pre-line">
            {heroTitle}
          </h1>
          <p className="text-base md:text-xl text-white/90 max-w-2xl mx-auto">
            {heroSubtitle}
          </p>
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href={rpath("/menu")}>
              <Button size="lg" className="text-base md:text-lg px-8 py-6 rounded-full w-full sm:w-auto">
                Order Now <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Items Section */}
      <section className="py-12 md:py-20 px-4 max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-10 md:mb-12">
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-foreground">Chef's Signatures</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm md:text-base">
            Discover our most loved dishes, prepared with passion and the finest seasonal ingredients.
          </p>
        </div>

        {isLoadingItems ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="w-full aspect-[4/3] rounded-xl" />
                <Skeleton className="h-6 w-2/3" />
                <Skeleton className="h-4 w-1/3" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {featuredItems?.slice(0, 3).map((item) => (
              <Link key={item.id} href={rpath(`/menu?item=${item.id}`)}>
                <Card className="group cursor-pointer overflow-hidden border-none shadow-none bg-transparent h-full flex flex-col">
                  <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden mb-4 bg-muted">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        <Utensils className="h-12 w-12 opacity-20" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-2 gap-4">
                      <h3 className="font-serif text-lg md:text-xl font-bold group-hover:text-primary transition-colors line-clamp-1">{item.name}</h3>
                      <span className="font-medium text-base md:text-lg shrink-0">{formatCurrency(item.price)}</span>
                    </div>
                    <p className="text-muted-foreground text-sm line-clamp-2">{item.description}</p>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Categories Section */}
      <section className="py-12 md:py-20 px-4 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-8 md:mb-10">
            <div>
              <h2 className="text-2xl md:text-3xl font-serif font-bold text-foreground mb-2">Browse by Category</h2>
              <p className="text-muted-foreground text-sm md:text-base">Find exactly what you're craving.</p>
            </div>
            <Link href={rpath("/menu")}>
              <Button variant="ghost" className="hidden sm:flex">
                View Full Menu <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>

          {isLoadingCategories ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="w-full aspect-square rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6">
              {categories?.slice(0, 4).map((category) => (
                <Link key={category.id} href={rpath(`/menu/${category.id}`)}>
                  <div className="group relative rounded-xl overflow-hidden aspect-square cursor-pointer bg-muted">
                    {category.imageUrl ? (
                      <img
                        src={category.imageUrl}
                        alt={category.name}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                    ) : (
                      <div className="w-full h-full bg-secondary" />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-4 md:p-6">
                      <h3 className="text-white font-serif font-bold text-base md:text-2xl">{category.name}</h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          <div className="mt-6 sm:hidden">
            <Link href={rpath("/menu")}>
              <Button variant="outline" className="w-full">View Full Menu</Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}
