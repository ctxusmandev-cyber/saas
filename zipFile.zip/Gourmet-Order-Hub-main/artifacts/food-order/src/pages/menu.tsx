import { Layout } from "@/components/layout";
import { Link, useParams } from "wouter";
import { useListCategories, useListItems } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { Plus, Minus, Utensils } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useRestaurantPath } from "@/lib/use-slug";

export default function Menu() {
  const params = useParams<{ slug: string; categoryId?: string }>();
  const activeCategoryId = params?.categoryId ? parseInt(params.categoryId, 10) : undefined;
  const rpath = useRestaurantPath();

  const { data: categories, isLoading: isLoadingCategories } = useListCategories();
  const { data: items, isLoading: isLoadingItems } = useListItems(
    activeCategoryId ? { categoryId: activeCategoryId } : undefined
  );

  const { items: cartItems, addToCart, updateQuantity } = useCart();

  const getQuantity = (id: number) => {
    return cartItems.find(i => i.menuItemId === id)?.quantity || 0;
  };

  return (
    <Layout>
      <div className="bg-primary/5 py-12 border-b">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">Our Menu</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Thoughtfully sourced, carefully crafted. Explore our seasonal offerings and timeless classics.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 flex flex-col md:flex-row gap-8">
        {/* Categories Sidebar */}
        <aside className="w-full md:w-64 shrink-0">
          <div className="sticky top-24">
            <h3 className="font-bold text-lg mb-4 font-serif">Categories</h3>
            {isLoadingCategories ? (
              <div className="space-y-2">
                {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : (
              <div className="flex md:flex-col overflow-x-auto md:overflow-visible gap-2 pb-4 md:pb-0">
                <Link href={rpath("/menu")}>
                  <Button
                    variant={!activeCategoryId ? "default" : "ghost"}
                    className="justify-start whitespace-nowrap"
                  >
                    All Items
                  </Button>
                </Link>
                {categories?.map((cat) => (
                  <Link key={cat.id} href={rpath(`/menu/${cat.id}`)}>
                    <Button
                      variant={activeCategoryId === cat.id ? "default" : "ghost"}
                      className="justify-start whitespace-nowrap"
                    >
                      {cat.name}
                    </Button>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </aside>

        {/* Menu Items Grid */}
        <main className="flex-1">
          {isLoadingItems ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="space-y-3">
                  <Skeleton className="w-full aspect-[4/3] rounded-xl" />
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/4" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ))}
            </div>
          ) : items?.length === 0 ? (
            <div className="text-center py-20 bg-muted/30 rounded-xl border border-dashed">
              <Utensils className="h-12 w-12 mx-auto text-muted-foreground opacity-50 mb-4" />
              <h3 className="text-xl font-bold mb-2 font-serif">No items found</h3>
              <p className="text-muted-foreground">We couldn't find any items in this category right now.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {items?.map((item) => {
                const quantity = getQuantity(item.id);
                return (
                  <div key={item.id} className={cn("group flex flex-col bg-card rounded-xl border overflow-hidden", !item.available && "opacity-60")}>
                    <div className="relative aspect-[4/3] bg-muted">
                      {item.imageUrl ? (
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Utensils className="h-10 w-10 text-muted-foreground/30" />
                        </div>
                      )}
                      {!item.available && (
                        <div className="absolute inset-0 bg-background/50 flex items-center justify-center backdrop-blur-sm">
                          <span className="bg-background text-foreground px-4 py-2 font-bold rounded shadow-sm">Sold Out</span>
                        </div>
                      )}
                    </div>

                    <div className="p-5 flex flex-col flex-1">
                      <div className="flex justify-between items-start gap-2 mb-2">
                        <h3 className="font-bold text-lg font-serif leading-tight">{item.name}</h3>
                        <span className="font-semibold text-primary">{formatCurrency(item.price)}</span>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-1">
                        {item.description}
                      </p>

                      <div className="mt-auto">
                        {quantity > 0 ? (
                          <div className="flex items-center justify-between bg-primary/5 rounded-lg p-1 border border-primary/20">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 rounded-md hover:bg-primary/20 hover:text-primary"
                              onClick={() => updateQuantity(item.id, quantity - 1)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="font-bold w-8 text-center">{quantity}</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 rounded-md hover:bg-primary/20 hover:text-primary"
                              onClick={() => updateQuantity(item.id, quantity + 1)}
                              disabled={!item.available}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <Button
                            className="w-full font-medium"
                            variant="secondary"
                            onClick={() => addToCart({ menuItemId: item.id, name: item.name, price: item.price, imageUrl: item.imageUrl || undefined })}
                            disabled={!item.available}
                          >
                            Add to Order
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>
    </Layout>
  );
}
