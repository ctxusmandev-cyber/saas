import { Router, type IRouter } from "express";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { db, ordersTable, orderItemsTable, menuItemsTable } from "@workspace/db";
import {
  CreateOrderBody,
  GetOrderParams,
  UpdateOrderStatusParams,
  UpdateOrderStatusBody,
  ListOrdersQueryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function rid(req: any): number | null {
  return (req as any).restaurantId ?? null;
}

async function getOrderWithItems(orderId: number) {
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId));
  if (!order) return null;

  const items = await db
    .select()
    .from(orderItemsTable)
    .where(eq(orderItemsTable.orderId, orderId));

  return {
    ...order,
    total: Number(order.total),
    createdAt: order.createdAt.toISOString(),
    paymentMethod: order.paymentMethod,
    items: items.map((i) => ({
      menuItemId: i.menuItemId,
      name: i.name,
      quantity: i.quantity,
      unitPrice: Number(i.unitPrice),
    })),
  };
}

router.get("/orders", async (req, res): Promise<void> => {
  const queryParsed = ListOrdersQueryParams.safeParse(req.query);
  const filters: ReturnType<typeof eq>[] = [];

  const restaurantId = rid(req);
  if (restaurantId !== null) {
    filters.push(eq(ordersTable.restaurantId, restaurantId));
  }

  if (queryParsed.success) {
    const { status, dateFrom, dateTo } = queryParsed.data as any;

    if (status) {
      filters.push(eq(ordersTable.status, status as typeof ordersTable.status._.data));
    }

    if (dateFrom) {
      filters.push(gte(ordersTable.createdAt, new Date(dateFrom + "T00:00:00Z")));
    }

    if (dateTo) {
      filters.push(lte(ordersTable.createdAt, new Date(dateTo + "T23:59:59Z")));
    }
  }

  let query = db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).$dynamic();
  if (filters.length > 0) {
    query = query.where(and(...filters));
  }

  const orders = await query;
  const result = await Promise.all(orders.map((o) => getOrderWithItems(o.id)));
  res.json(result.filter(Boolean));
});

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { items: orderItems, ...orderData } = parsed.data;
  const restaurantId = rid(req) ?? undefined;

  let total = 0;
  const resolvedItems: { menuItemId: number; name: string; quantity: number; unitPrice: number }[] = [];

  for (const item of orderItems) {
    const [menuItem] = await db
      .select()
      .from(menuItemsTable)
      .where(eq(menuItemsTable.id, item.menuItemId));

    if (!menuItem) {
      res.status(400).json({ error: `Menu item ${item.menuItemId} not found` });
      return;
    }

    const unitPrice = Number(menuItem.price);
    total += unitPrice * item.quantity;
    resolvedItems.push({
      menuItemId: menuItem.id,
      name: menuItem.name,
      quantity: item.quantity,
      unitPrice,
    });
  }

  const [order] = await db.insert(ordersTable).values({
    ...orderData,
    restaurantId,
    total: String(total),
    status: "pending",
  }).returning();

  await db.insert(orderItemsTable).values(
    resolvedItems.map((i) => ({
      orderId: order.id,
      menuItemId: i.menuItemId,
      name: i.name,
      quantity: i.quantity,
      unitPrice: String(i.unitPrice),
    }))
  );

  const fullOrder = await getOrderWithItems(order.id);
  res.status(201).json(fullOrder);
});

router.get("/orders/:id", async (req, res): Promise<void> => {
  const params = GetOrderParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const order = await getOrderWithItems(params.data.id);
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  res.json(order);
});

router.patch("/orders/:id", async (req, res): Promise<void> => {
  const params = UpdateOrderStatusParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateOrderStatusBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [order] = await db
    .update(ordersTable)
    .set({ status: parsed.data.status as typeof ordersTable.status._.data })
    .where(eq(ordersTable.id, params.data.id))
    .returning();

  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  const fullOrder = await getOrderWithItems(order.id);
  res.json(fullOrder);
});

export default router;
